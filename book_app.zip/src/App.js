import React, { Component } from "react";
import Routers from "./Router";

class App extends Component {
  render() {
    return <Routers />;
  }
}

export default App;
